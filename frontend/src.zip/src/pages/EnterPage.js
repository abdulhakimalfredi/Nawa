import React, { useState, useEffect } from "react";
import "../assets/styles/App.css";
import HeaderWeb from "../components/HeaderWeb";
import TheRoadMap from "../components/TheRoadMap";
import Card from "../components/Card";
import Instructions from "../components/Instructions";
import KnowledgeBase from "../components/KnowledgeBase";
import StudyDashboard from "../components/StudyDashboard";

export default function EnterPage() {
  const [topics, setTopics] = useState([]);

  useEffect(() => {
    fetch("http://127.0.0.1:8001/api/topics")
      .then((res) => res.json())
      .then((data) => setTopics(data))
      .catch((err) => console.log(err));
  }, []);
  const [ActivePath, setActivePath] = useState({});
  const [showInstructions, setShowInstructions] = useState(false);

  const [completedTopics, setCompletedTopics] = useState(() => {
    const savedProgress = localStorage.getItem("my_progress");
    return savedProgress ? JSON.parse(savedProgress) : [];
  });

  useEffect(() => {
    localStorage.setItem("my_progress", JSON.stringify(completedTopics));
  }, [completedTopics]);

  return (
    <div className="App">
      <div>
        <HeaderWeb />

        {/* Instructions Toggle Banner */}
        <div className="instructions-banner">
          <button
            className="instructions-toggle"
            onClick={() => setShowInstructions(!showInstructions)}
          >
            <span className="instructions-toggle-icon">
              {showInstructions ? "📖" : "📋"}
            </span>
            <span className="instructions-toggle-text">
              {showInstructions
                ? "Hide Instructions"
                : "Read Instructions Before You Start"}
            </span>
            <span
              className="instructions-toggle-arrow"
              style={{
                transform: showInstructions ? "rotate(180deg)" : "rotate(0)",
              }}
            >
              ▼
            </span>
          </button>

          {showInstructions && (
            <div className="instructions-dropdown">
              <Instructions ActivePath={ActivePath} />
            </div>
          )}
        </div>

        {/* Main 3-Column Layout */}
        <div className="main-container">
          {/* Roadmap - Left */}
          <div className="roadmap-section">
            <TheRoadMap
              activePath={ActivePath}
              setActivePath={setActivePath}
              paths={[
                {
                  id: "General",
                  title: "General",
                  progress: 50,
                  done: 3,
                  total: 6,
                },
                {
                  id: "FrontEnd",
                  title: "Front-End Development",
                  progress: 33,
                  done: 2,
                  total: 6,
                },
                {
                  id: "BackEnd",
                  title: "Back-End Development",
                  progress: 0,
                  done: 0,
                  total: 8,
                },
              ]}
            />
          </div>

          {/* Knowledge Base - Center */}
          <div className="knowledge-base">
            <Card>
              <KnowledgeBase
                ActivePath={ActivePath}
                TopicList={topics}
                completedTopics={completedTopics}
                setCompletedTopics={setCompletedTopics}
              />
            </Card>
          </div>

          {/* Stats - Right */}
          <div className="tracker-section">
            <Card>
              <StudyDashboard
                completedTopics={completedTopics}
                TopicList={topics}
              />
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
