
export default function HeaderWeb({userName}) {
    return( 
        <div style={{
            width: "100%", 
            backgroundColor: "#162432ff",
            height: "200px",
            color: "whitesmoke", 
            display: "flex", 
            justifyContent: "center", 
            alignItems: "center",
            fontSize:"30px",
            boxShadow: "0px 5px 13px rgb(0, 0, 0.4)",
            }}>
        <h1 style={{textAlign:"center"}}>Darb
            <br/>
            Your Jouerny of learnig Start From Here {userName}
            </h1>
        </div>
    );
}

