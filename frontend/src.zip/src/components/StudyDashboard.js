export default function StudyDashboard({ completedTopics, TopicList }) {
  console.log("TopicList:", TopicList);
  console.log("TopicList length:", TopicList ? TopicList.length : "undefined");
  console.log("completedTopics:", completedTopics);
  console.log("completedTopics length:", completedTopics.length);

  const totalTopics = TopicList ? TopicList.length : 0;
  const completedCount = completedTopics.length;
  const percentage = totalTopics > 0 
    ? Math.round((completedCount / totalTopics) * 100) 
    : 0;

  return (
    <div className="dashboard-card">
      <h3>Your Stats</h3>
      <p>Total: {totalTopics}</p>
      <p>Completed: {completedCount}</p>
      <p>{percentage}%</p>
      <progress value={percentage} max="100"></progress>
    </div>
  );
}